import './style.css'
import { pintaActividad } from './counter';
import type {} from './actividad-interface.ts';

const appElemento = document.querySelector('#app');
if(appElemento){
    appElemento.innerHTML= `
    <div class="form-container">
        <h2>Configurar Actividad</h2>
        <form id="activity-form">
            
            <!-- Selector de Dificultad -->
            <div class="form-group">
                <label for="difficulty">Dificultad:</label>
                <select id="difficulty" name="difficulty">
                    <option value="easy">Fácil (easy)</option>
                    <option value="medium">Media (medium)</option>
                    <option value="hard">Difícil (hard)</option>
                </select>
            </div>

            <!-- Selector de Tipo de Actividad -->
            <div class="form-group">
                <label for="type">Tipo de Actividad:</label>
                <select id="type" name="type">
                    <option value="ordenadores">Ordenadores</option>
                    <option value="deporte">Deporte</option>
                    <option value="videojuegos">Videojuegos</option>
                </select>
            </div>

            <button type="submit">Generar Actividad</button>
        </form>
    </div>

    <div id="resultado" style="margin-top: 20px; width: 100%; max-width: 600px;"></div>
    `
}

// Gestionamos el evento del formulario
const form = document.querySelector("#activity-form") as HTMLFormElement;
if (form) {
    form.addEventListener("submit", (event: SubmitEvent) => {
        event.preventDefault();

        const dificultadSeleccionada = document.querySelector("#difficulty") as HTMLSelectElement;
        const tipoSeleccionado = document.querySelector("#type") as HTMLSelectElement;

        const valorDificultad: string = dificultadSeleccionada.value;
        const valorTipo: string = tipoSeleccionado.value;

        pintaActividad(valorDificultad, valorTipo);
    });
}

const formu = document.querySelector("#activity-form") as HTMLFormElement;
const botonSubmit = form.querySelector('button[type="submit"]') as HTMLButtonElement;

let bloqueado = false;

if (formu && botonSubmit) {
    formu.addEventListener("submit", (event: SubmitEvent) => {
        event.preventDefault();

        if (bloqueado) {
            alert("Espera unos segundos antes de hacer otra petición.");
            return;
        }

        // Bloqueamos y programamos que se libere a los 5 segundos
        bloqueado = true;
        setTimeout(() => {
            bloqueado = false;
        }, 5000);

        // Capturamos los valores y lanzamos la función
        const dificultadSeleccionada = document.querySelector("#difficulty") as HTMLSelectElement;
        const tipoSeleccionado = document.querySelector("#type") as HTMLSelectElement;
        
        pintaActividad(dificultadSeleccionada.value, tipoSeleccionado.value);
    });
}