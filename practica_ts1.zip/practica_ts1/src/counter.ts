import type { Usuario } from "./actividad-interface";
import type { Foto } from "./foto-interface";



export async function pintaActividad(dificultad:string, tipo:string){
    let url = 'https://opentdb.com/api.php?'
    url += `amount=1`;
    if(tipo.toLowerCase() === 'ordenadores') url+=`&category=18`;
    if(tipo.toLowerCase() === 'videojuegos') url +=`&category=15`;
    if(tipo.toLowerCase() === 'deportes') url += `&category=21`;
    url +=`&difficulty=${dificultad}&type=multiple`;
    console.log(url);
    const respuesta: Usuario = await peticionActividad<Usuario>(url);

    const contenedor = document.querySelector("#resultado");
    if (contenedor) {
        contenedor.innerHTML = "";
        const respuestaActual = respuesta.results[0].correct_answer;
        if(respuestaActual != ''){
            console.log(respuesta.results[0].correct_answer);
            
            
            const keyword:string = `${respuesta.results[0].category.replace(":",'')}`;
            const urlFt = `https://pixabay.com/api/?key=57926645-de76d3933548bd9eef2b8bc6b&q=${keyword}&image_type=photo`;
            console.log(urlFt);
            
            const urlFoto:Foto = await peticionActiviFoto(urlFt);
            // 4. Pintamos la tarjeta completa en la pantalla
            contenedor.innerHTML = `
                <div style="background: #1e1e1e; border: 1px solid #333; border-radius: 10px; padding: 20px; margin-top: 20px; color: white; max-width: 600px;">
                    <p><strong>Actividad:</strong> ${respuestaActual}</p>
                    
                    <!-- Imagen generada por Pollinations -->
                    <div style="width: 100%; border-radius: 8px; overflow: hidden; margin-top: 10px; background: #000;">
                        <img src="${urlFoto.hits[Math.floor(Math.random() * (urlFoto.hits.length - 1 + 1)) + 1].largeImageURL}" alt="${respuestaActual}" style="width: 100%; height: 200px; object-fit: cover; display: block;" />
                    </div>

                </div>
            `;
        }
    }
    
}

async function peticionActividad<Usuario>(url:string):Promise<Usuario>{
    return await peticion(url) as Usuario;
}

async function peticionActiviFoto<Foto>(url:string):Promise<Foto>{
    return await peticion(url) as Foto;
}


async function peticion<T>(url:string):Promise<T>{
    try{
        const respuesta = await fetch(url)
        if(!respuesta.ok) throw new Error(`Error: ${respuesta.status}`)

        const actividad = await respuesta.json();
        console.log(actividad);
        return actividad;     
    }catch(error){
      console.error("Error en la petición", error);
        throw error;
    }
}