export interface Usuario {
    response_code: number;
    results:       Result[];
}

export interface Result {
    type:              Type;
    difficulty:        Difficulty;
    category:          Category;
    question:          string;
    correct_answer:    string;
    incorrect_answers: string[];
}

export type Category = "Sports";

export type Difficulty = "easy";

export type Type = "multiple" | "boolean";
